import * as fengari from 'https://cdn.jsdelivr.net/npm/fengari@0.1.4/src/fengari.js';
import { lua, lauxlib, lualib, to_luastring, to_jsstring } from 'https://cdn.jsdelivr.net/npm/fengari@0.1.4/src/fengari.js';

export class LuaRuntime{
 constructor({log=()=>{},onError=()=>{},getSelected=()=>null,getObjects=()=>[],toast=()=>{}}={}){this.log=log;this.onError=onError;this.getSelected=getSelected;this.getObjects=getObjects;this.toast=toast;this.state=null;this.stopped=false}
 async run(code,object){
  this.stop();this.stopped=false;
  try{
   const L=lauxlib.luaL_newstate();lualib.luaL_openlibs(L);this.state=L;
   // Remove common escape hatches and library access not needed for simple game scripts.
   ['dofile','loadfile','require','collectgarbage'].forEach(n=>{lua.lua_pushnil(L);lua.lua_setglobal(L,to_luastring(n));});
   const pushFn=(name,fn)=>{lua.lua_pushjsfunction(L,(L2)=>{try{const args=[];for(let i=1;i<=lua.lua_gettop(L2);i++)args.push(readValue(L2,i));const out=fn(...args);if(out&&typeof out.then==='function'){this.log('Note: wait() is available as a timing helper, but this starter runs each script synchronously.');lua.lua_pushnumber(L2,0);return 1}if(Array.isArray(out)){out.forEach(v=>pushValue(L2,v));return out.length}if(out===undefined){return 0}pushValue(L2,out);return 1}catch(e){this.onError(e.message);return 0}});lua.lua_setglobal(L,to_luastring(name))};
   const readValue=(L2,i)=>{const t=lua.lua_type(L2,i);if(t===lua.LUA_TNUMBER)return lua.lua_tonumber(L2,i);if(t===lua.LUA_TBOOLEAN)return !!lua.lua_toboolean(L2,i);if(t===lua.LUA_TSTRING)return to_jsstring(lua.lua_tostring(L2,i));return null};
   const pushValue=(L2,v)=>{if(typeof v==='number')lua.lua_pushnumber(L2,v);else if(typeof v==='boolean')lua.lua_pushboolean(L2,v);else lua.lua_pushstring(L2,to_luastring(String(v)))};
   pushFn('print',(...a)=>this.log(a.map(String).join('\t')));
   pushFn('warn',(...a)=>this.log('WARN: '+a.map(String).join('\t')));
   pushFn('setColor',color=>{if(!/^#[0-9a-fA-F]{6}$/.test(String(color)))throw new Error('setColor expects a hex color');object.material.color.set(color)});
   pushFn('setPosition',(x,y,z)=>object.position.set(Number(x)||0,Number(y)||0,Number(z)||0));
   pushFn('setName',name=>{object.name=String(name).slice(0,50)});
   pushFn('getName',()=>object.name);
   pushFn('getPosition',()=>[object.position.x,object.position.y,object.position.z]);
   pushFn('getObjectCount',()=>this.getObjects().length);
   pushFn('impulse',(x=0,y=0,z=0)=>{object.userData.scriptImpulse=[Number(x)||0,Number(y)||0,Number(z)||0]});
   // Lua-friendly part table: part.setColor("#..."), part.setPosition(x,y,z), etc.
   lua.lua_createtable(L,0,5);
   for(const [name,globalName] of [['setColor','setColor'],['setPosition','setPosition'],['setName','setName'],['getName','getName'],['getPosition','getPosition'],['impulse','impulse']]){lua.lua_getglobal(L,to_luastring(globalName));lua.lua_setfield(L,-2,to_luastring(name))}
   lua.lua_setglobal(L,to_luastring('part'));
   lua.lua_createtable(L,0,1);lua.lua_getglobal(L,to_luastring('getObjectCount'));lua.lua_setfield(L,-2,to_luastring('getObjectCount'));lua.lua_setglobal(L,to_luastring('workspace'));
   const status=lauxlib.luaL_loadstring(L,to_luastring(code));
   if(status!==lua.LUA_OK)throw new Error(to_jsstring(lua.lua_tostring(L,-1)));
   const result=lua.lua_pcall(L,0,lua.LUA_MULTRET,0);
   if(result!==lua.LUA_OK)throw new Error(to_jsstring(lua.lua_tostring(L,-1)));
   this.log('Script finished.');
  }catch(err){this.onError(err?.message||String(err))}
 }
 step(){}
 stop(){if(this.state){lua.lua_close(this.state);this.state=null}this.stopped=true}
}
