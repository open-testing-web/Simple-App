import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.164.1/build/three.module.js';
import { OrbitControls } from 'https://cdn.jsdelivr.net/npm/three@0.164.1/examples/jsm/controls/OrbitControls.js';
import { TransformControls } from 'https://cdn.jsdelivr.net/npm/three@0.164.1/examples/jsm/controls/TransformControls.js';

export function createScene(viewport){
 const scene=new THREE.Scene();scene.background=new THREE.Color('#151922');scene.fog=new THREE.Fog('#151922',45,120);
 const camera=new THREE.PerspectiveCamera(50,1,.1,500);camera.position.set(11,10,14);
 const renderer=new THREE.WebGLRenderer({antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio||1,2));renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.1;viewport.prepend(renderer.domElement);
 const orbit=new OrbitControls(camera,renderer.domElement);orbit.enableDamping=true;orbit.target.set(0,1,0);orbit.maxPolarAngle=Math.PI*.495;orbit.minDistance=2;orbit.maxDistance=100;
 const transform=new TransformControls(camera,renderer.domElement);scene.add(transform.getHelper());transform.setMode('translate');transform.addEventListener('dragging-changed',e=>orbit.enabled=!e.value);
 scene.add(new THREE.HemisphereLight(0xc8ddff,0x34303a,2));const sun=new THREE.DirectionalLight(0xfff1d6,3.2);sun.position.set(12,22,8);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);sun.shadow.camera.left=-35;sun.shadow.camera.right=35;sun.shadow.camera.top=35;sun.shadow.camera.bottom=-35;scene.add(sun);
 const grid=new THREE.GridHelper(100,100,0x59677d,0x343d4c);grid.position.y=.001;scene.add(grid);
 const floor=new THREE.Mesh(new THREE.PlaneGeometry(200,200),new THREE.MeshStandardMaterial({color:'#343b49',roughness:.92}));floor.rotation.x=-Math.PI/2;floor.position.y=-.03;floor.receiveShadow=true;scene.add(floor);
 const objects=[];let id=1;let selected=null;
 function mat(color,type='plastic'){if(type==='metal')return new THREE.MeshStandardMaterial({color,metalness:.82,roughness:.25});if(type==='glass')return new THREE.MeshPhysicalMaterial({color,transparent:true,opacity:.5,roughness:.08,transmission:.12});if(type==='neon')return new THREE.MeshStandardMaterial({color,emissive:color,emissiveIntensity:1.6});return new THREE.MeshStandardMaterial({color,roughness:.55,metalness:.03})}
 function geometry(type){if(type==='Sphere')return new THREE.SphereGeometry(.5,32,24);if(type==='Cylinder')return new THREE.CylinderGeometry(.5,.5,1,32);if(type==='Platform')return new THREE.BoxGeometry(20,.5,20);return new THREE.BoxGeometry(1,1,1)}
 function addPart(type='Block',cfg={}){const color=cfg.color||(type==='Platform'?'#4a9b68':'#4b8df8');const mesh=new THREE.Mesh(geometry(type),mat(color,cfg.material||'plastic'));mesh.name=cfg.name||`${type} ${id}`;mesh.userData={id:cfg.id||id++,type:type==='Platform'?'Block':type,materialType:cfg.material||'plastic',anchored:cfg.anchored!==false,collidable:cfg.collidable!==false,mass:cfg.mass||1,script:cfg.script||'',editorObject:true};if(cfg.id)id=Math.max(id,cfg.id+1);mesh.castShadow=true;mesh.receiveShadow=true;if(cfg.position)mesh.position.fromArray(cfg.position);else mesh.position.set((Math.random()-.5)*1.5,type==='Platform'?-.25:1,(Math.random()-.5)*1.5);if(cfg.rotation)mesh.rotation.set(...cfg.rotation);if(cfg.scale)mesh.scale.set(...cfg.scale);else if(type==='Sphere'||type==='Cylinder')mesh.scale.set(2,2,2);scene.add(mesh);objects.push(mesh);return mesh}
 function remove(o){scene.remove(o);o.geometry.dispose();o.material.dispose();const i=objects.indexOf(o);if(i>=0)objects.splice(i,1);if(selected===o)select(null)}
 function clear(){[...objects].forEach(remove);id=1}
 function select(o){selected=o&&objects.includes(o)?o:null;transform.detach();if(selected)transform.attach(selected)}
 function setMode(mode){transform.setMode(mode)}
 function setMaterial(o,type){const c='#'+o.material.color.getHexString();o.material.dispose();o.material=mat(c,type)}
 function syncPhysicsBody(){}
 function duplicate(o){const cfg={name:o.name+' Copy',type:o.userData.type,position:[o.position.x+2,o.position.y,o.position.z],rotation:[o.rotation.x,o.rotation.y,o.rotation.z],scale:o.scale.toArray(),color:'#'+o.material.color.getHexString(),material:o.userData.materialType,anchored:o.userData.anchored,collidable:o.userData.collidable,mass:o.userData.mass,script:o.userData.script};return addPart(o.userData.type,cfg)}
 function focus(o){const box=new THREE.Box3().setFromObject(o),center=box.getCenter(new THREE.Vector3()),size=box.getSize(new THREE.Vector3()).length(),dir=new THREE.Vector3().subVectors(camera.position,orbit.target).normalize();orbit.target.copy(center);camera.position.copy(center).add(dir.multiplyScalar(Math.max(size*1.7,5)));orbit.update()}
 function resetCamera(){camera.position.set(11,10,14);orbit.target.set(0,1,0);orbit.update()}
 function resize(){const r=viewport.getBoundingClientRect();if(!r.width||!r.height)return;renderer.setSize(r.width,r.height,false);camera.aspect=r.width/r.height;camera.updateProjectionMatrix()}
 new ResizeObserver(resize).observe(viewport);window.addEventListener('resize',resize);document.addEventListener('fullscreenchange',()=>setTimeout(resize,50));
 const raycaster=new THREE.Raycaster(),mouse=new THREE.Vector2();
 renderer.domElement.addEventListener('pointerdown',e=>{if(e.button!==0)return;setTimeout(()=>{if(transform.dragging)return;const r=renderer.domElement.getBoundingClientRect();mouse.set((e.clientX-r.left)/r.width*2-1,-((e.clientY-r.top)/r.height)*2+1);raycaster.setFromCamera(mouse,camera);const hits=raycaster.intersectObjects(objects,false);select(hits.length?hits[0].object:null);if(api.onSelect)api.onSelect(selected)},0)});
 const api={scene,camera,renderer,orbit,transform,grid,objects,addPart,remove,clear,select,setMode,setMaterial,syncPhysicsBody,duplicate,focus,resetCamera,resize,detachTransform:()=>transform.detach(),getCameraState:()=>({position:camera.position.toArray(),target:orbit.target.toArray()}),restoreCamera:s=>{camera.position.fromArray(s.position);orbit.target.fromArray(s.target);orbit.update()},update:()=>{orbit.update();renderer.render(scene,camera)},set onSelect(fn){this._onSelect=fn},get onSelect(){return this._onSelect}};
 resize();return api
}
