import * as CANNON from 'https://cdn.jsdelivr.net/npm/cannon-es@0.20.0/dist/cannon-es.js';
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.164.1/build/three.module.js';

export class PhysicsWorld{
 constructor(scene){this.scene=scene;this.world=new CANNON.World({gravity:new CANNON.Vec3(0,-18,0)});this.world.broadphase=new CANNON.SAPBroadphase(this.world);this.world.allowSleep=true;this.bodies=new Map();this.running=false;this.player=null;this.playerBody=null;this.material=new CANNON.Material('default');this.world.defaultContactMaterial.friction=.45;this.world.defaultContactMaterial.restitution=.05}
 start(objects){this.stop();this.world=new CANNON.World({gravity:new CANNON.Vec3(0,-18,0)});this.world.broadphase=new CANNON.SAPBroadphase(this.world);this.world.allowSleep=true;this.world.defaultContactMaterial.friction=.45;this.bodies.clear();
  const floorMat=new CANNON.Material('floor');const floor=new CANNON.Body({mass:0,material:floorMat,shape:new CANNON.Plane()});floor.quaternion.setFromEuler(-Math.PI/2,0,0);floor.position.set(0,-.03,0);this.world.addBody(floor);this.floor=floor;
  for(const o of objects)this.addObject(o);
  this.player=new THREE.Mesh(new THREE.CapsuleGeometry(.4,.9,4,8),new THREE.MeshStandardMaterial({color:'#ffd166'}));this.player.castShadow=true;this.player.position.set(0,1.4,5);this.scene.add(this.player);
  this.playerBody=new CANNON.Body({mass:5,shape:new CANNON.Sphere(.48),position:new CANNON.Vec3(0,1.4,5),fixedRotation:true,linearDamping:.2});this.playerBody.updateMassProperties();this.world.addBody(this.playerBody);this.running=true;
 }
 addObject(o){const anchored=o.userData.anchored!==false;let shape;if(o.userData.type==='Sphere')shape=new CANNON.Sphere(.5*Math.max(o.scale.x,o.scale.y,o.scale.z));else if(o.userData.type==='Cylinder')shape=new CANNON.Cylinder(.5*Math.max(o.scale.x,o.scale.z),.5*Math.max(o.scale.x,o.scale.z),o.scale.y,12);else shape=new CANNON.Box(new CANNON.Vec3(Math.max(.05,o.scale.x/2),Math.max(.05,o.scale.y/2),Math.max(.05,o.scale.z/2)));
  const body=new CANNON.Body({mass:anchored?0:Math.max(.1,o.userData.mass||1),shape,position:new CANNON.Vec3(o.position.x,o.position.y,o.position.z),material:this.material,linearDamping:.08,angularDamping:.2});body.quaternion.set(o.quaternion.x,o.quaternion.y,o.quaternion.z,o.quaternion.w);body.userData={mesh:o};if(o.userData.collidable===false)body.collisionResponse=false;this.world.addBody(body);this.bodies.set(o,body)}
 step(dt,keys={}){if(!this.running)return;this.world.step(1/60,dt,3);for(const [o,b] of this.bodies){if(o.userData.anchored===false){o.position.set(b.position.x,b.position.y,b.position.z);o.quaternion.set(b.quaternion.x,b.quaternion.y,b.quaternion.z,b.quaternion.w)}}
  if(this.playerBody){const speed=6;const forward=new CANNON.Vec3(0,0,-1),right=new CANNON.Vec3(1,0,0),move=new CANNON.Vec3();if(keys.w)move.vadd(forward,move);if(keys.s)move.vsub(forward,move);if(keys.d)move.vadd(right,move);if(keys.a)move.vsub(right,move);if(move.lengthSquared()>0){move.normalize();this.playerBody.velocity.x=move.x*speed;this.playerBody.velocity.z=move.z*speed}else{this.playerBody.velocity.x*=.8;this.playerBody.velocity.z*=.8}this.playerBody.velocity.y=Math.max(this.playerBody.velocity.y,-22);this.player.position.set(this.playerBody.position.x,this.playerBody.position.y-.25,this.playerBody.position.z)}
 }
 stop(){if(this.player){this.scene.remove(this.player);this.player.geometry.dispose();this.player.material.dispose();this.player=null}this.playerBody=null;this.running=false;this.bodies.clear()}
 applyImpulse(o,x,y,z){const b=this.bodies.get(o);if(b&&b.mass>0)b.applyImpulse(new CANNON.Vec3(x,y,z),b.position)}
}
