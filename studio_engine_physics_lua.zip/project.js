export class ProjectStore{
 constructor(engine){this.engine=engine}
 serialize(){return {format:'StudioEngineProject',version:2,objects:this.engine.objects.map(o=>({id:o.userData.id,name:o.name,type:o.userData.type,position:o.position.toArray(),rotation:[o.rotation.x,o.rotation.y,o.rotation.z],scale:o.scale.toArray(),color:'#'+o.material.color.getHexString(),material:o.userData.materialType||'plastic',anchored:o.userData.anchored!==false,collidable:o.userData.collidable!==false,mass:o.userData.mass||1,script:o.userData.script||''})),camera:this.engine.getCameraState(),gridVisible:this.engine.grid.visible}}
 download(){const blob=new Blob([JSON.stringify(this.serialize(),null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='studio-engine-project.json';a.click();URL.revokeObjectURL(url)}
 load(data){if(!data||!Array.isArray(data.objects))throw new Error('This is not a Studio Engine project JSON file');this.engine.clear();data.objects.forEach(o=>this.engine.addPart(o.type||'Block',o));if(data.camera)this.engine.restoreCamera(data.camera);this.engine.grid.visible=data.gridVisible!==false}
}
