import { createScene } from './scene.js';
import { PhysicsWorld } from './physics.js';
import { LuaRuntime } from './lua-runtime.js';
import { ProjectStore } from './project.js';

const $=id=>document.getElementById(id);
const viewport=$('viewport');
const engine=createScene(viewport);
const physics=new PhysicsWorld(engine.scene);
const lua=new LuaRuntime({
  log: msg=>appendConsole(msg),
  onError: msg=>appendConsole('ERROR: '+msg),
  getSelected:()=>selected,
  getObjects:()=>engine.objects,
  toast
});
const store=new ProjectStore(engine);
let selected=null, playing=false, gridVisible=true, savedCamera=null, lastTime=performance.now(), history=[], future=[], toastTimer;
let keys={};
function toast(s){$('toast').textContent=s;$('toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').classList.remove('show'),2200)}
function appendConsole(s){const c=$('console');c.textContent+=(c.textContent?'\n':'')+String(s);c.scrollTop=c.scrollHeight}
function markChanged(){$('status').textContent='Unsaved changes';$('saveStatus').textContent='Unsaved changes'}
function state(){return engine.objects.map(o=>({id:o.userData.id,name:o.name,type:o.userData.type,position:o.position.toArray(),rotation:[o.rotation.x,o.rotation.y,o.rotation.z],scale:o.scale.toArray(),color:'#'+o.material.color.getHexString(),material:o.userData.materialType||'plastic',anchored:o.userData.anchored!==false,collidable:o.userData.collidable!==false,mass:o.userData.mass||1,script:o.userData.script||''}))}
function historyPush(){history.push(JSON.stringify(state()));if(history.length>50)history.shift();future=[];historyButtons()}
function historyButtons(){$('undoBtn').disabled=!history.length;$('redoBtn').disabled=!future.length}
function select(obj){selected=engine.objects.includes(obj)?obj:null;engine.select(selected);renderTree();syncProps();$('hint').style.display=selected?'none':'block'}
engine.onSelect = obj => { selected = obj; renderTree(); syncProps(); $('hint').style.display = selected ? 'none' : 'block'; };
function renderTree(){const root=$('tree');root.innerHTML='';engine.objects.forEach(o=>{const row=document.createElement('div');row.className='tree-row'+(o===selected?' selected':'');const icon=o.userData.type==='Sphere'?'●':o.userData.type==='Cylinder'?'⬭':'▰';row.innerHTML=`<span class="tree-icon">${icon}</span><span class="tree-name"></span>`;row.querySelector('.tree-name').textContent=o.name;row.onclick=()=>select(o);root.append(row)});$('objectCount').textContent=`${engine.objects.length} object${engine.objects.length===1?'':'s'}`}
function syncProps(){const on=!!selected;$('empty').hidden=on;$('props').hidden=!on;$('typeTag').textContent=selected?selected.userData.type:'Nothing selected';if(!on)return;
$('pName').value=selected.name;
[['px','py','pz'],['sx','sy','sz'],['rx','ry','rz']].forEach((ids,group)=>ids.forEach((id,i)=>{let v;if(group===0)v=selected.position.getComponent(i);else if(group===1)v=selected.scale.getComponent(i)*(selected.userData.type==='Sphere'||selected.userData.type==='Cylinder'?2:1);else v=THREE_DEG(selected.rotation.getComponent(i));$(id).value=round(v)}));
const c='#'+selected.material.color.getHexString();$('pColor').value=c;$('pColorText').value=c;$('pMaterial').value=selected.userData.materialType||'plastic';$('pAnchored').checked=selected.userData.anchored!==false;$('pCollide').checked=selected.userData.collidable!==false;$('pMass').value=selected.userData.mass||1;
}
function THREE_DEG(r){return r*180/Math.PI}function round(n){return Math.round(n*100)/100}
function propChange(id){if(!selected)return;historyPush();if(id==='pName')selected.name=$('pName').value.trim()||'Part';else if(['px','py','pz'].includes(id))selected.position.set(...['px','py','pz'].map(x=>Number($(x).value)||0));else if(['sx','sy','sz'].includes(id)){const f=(selected.userData.type==='Sphere'||selected.userData.type==='Cylinder')?2:1;selected.scale.set(...['sx','sy','sz'].map(x=>Math.max(.1,Number($(x).value)||.1)/f))}else if(['rx','ry','rz'].includes(id))selected.rotation.set(...['rx','ry','rz'].map(x=>(Number($(x).value)||0)*Math.PI/180));else if(id==='pColor'||id==='pColorText'){const c=$(id).value;if(!/^#[0-9a-fA-F]{6}$/.test(c)){toast('Use a hex color such as #4b8df8');return}selected.material.color.set(c);if(selected.userData.materialType==='neon')selected.material.emissive.set(c);$('pColor').value=c;$('pColorText').value=c}else if(id==='pMaterial'){selected.userData.materialType=$('pMaterial').value;engine.setMaterial(selected,selected.userData.materialType)}else if(id==='pAnchored')selected.userData.anchored=$('pAnchored').checked;else if(id==='pCollide')selected.userData.collidable=$('pCollide').checked;else if(id==='pMass')selected.userData.mass=Math.max(.1,Number($('pMass').value)||1);engine.syncPhysicsBody(selected);renderTree();syncProps();markChanged()}
['pName','px','py','pz','sx','sy','sz','rx','ry','rz','pColor','pColorText','pMaterial','pAnchored','pCollide','pMass'].forEach(id=>$(id).addEventListener('change',()=>propChange(id)));
function add(type){if(playing){toast('Stop Play mode before editing.');return}historyPush();const o=engine.addPart(type);select(o);markChanged();toast(type+' inserted')}
$('blockBtn').onclick=()=>add('Block');$('sphereBtn').onclick=()=>add('Sphere');$('cylinderBtn').onclick=()=>add('Cylinder');$('groundBtn').onclick=()=>add('Platform');
document.querySelectorAll('.mode').forEach(b=>b.onclick=()=>{document.querySelectorAll('.mode').forEach(x=>x.classList.toggle('active',x===b));engine.setMode(b.dataset.mode);toast(b.dataset.mode+' tool selected')});
$('gridBtn').onclick=()=>{gridVisible=!gridVisible;engine.grid.visible=gridVisible;$('gridBtn').classList.toggle('active',gridVisible)};
$('focusBtn').onclick=()=>selected?engine.focus(selected):toast('Select an object first.');
$('resetBtn').onclick=()=>engine.resetCamera();
$('collapseBtn').onclick=()=>{document.querySelector('.workspace').classList.toggle('hide-explorer');$('collapseBtn').textContent=document.querySelector('.workspace').classList.contains('hide-explorer')?'+':'−';engine.resize()};
$('fullscreenBtn').onclick=async()=>{try{if(!document.fullscreenElement)await document.querySelector('.center').requestFullscreen();else await document.exitFullscreen()}catch{toast('Fullscreen is unavailable here')}};
$('renameBtn').onclick=()=>{if(!selected){toast('Select an object first');return}$('pName').focus();$('pName').select()};
$('duplicateBtn').onclick=()=>{if(!selected)return;historyPush();const o=engine.duplicate(selected);select(o);markChanged()};
$('deleteBtn').onclick=()=>{if(!selected)return;historyPush();engine.remove(selected);select(null);renderTree();markChanged();toast('Object deleted')};
$('newBtn').onclick=()=>{if(!confirm('Create a new project? Unsaved changes will be lost.'))return;stopPlay();historyPush();engine.clear();select(null);renderTree();markChanged()};
$('saveBtn').onclick=()=>{store.download();$('status').textContent='Project saved';$('saveStatus').textContent='Project JSON downloaded';toast('Project saved')};
$('openBtn').onclick=()=>$('fileInput').click();
$('fileInput').onchange=async e=>{const f=e.target.files[0];if(!f)return;try{const data=JSON.parse(await f.text());stopPlay();historyPush();store.load(data);select(null);renderTree();markChanged();toast('Project loaded')}catch(err){toast('Could not load project: '+err.message)}finally{e.target.value=''}};
$('undoBtn').onclick=()=>{if(!history.length)return;future.push(JSON.stringify(state()));restore(JSON.parse(history.pop()));historyButtons();toast('Undo complete')};
$('redoBtn').onclick=()=>{if(!future.length)return;history.push(JSON.stringify(state()));restore(JSON.parse(future.pop()));historyButtons();toast('Redo complete')};
function restore(s){engine.clear();s.forEach(o=>engine.addPart(o.type,o));select(null);renderTree();markChanged()}
function openScript(){if(!selected){toast('Select an object first');return}$('scriptModal').classList.remove('hidden');$('scriptTarget').textContent='Script attached to '+selected.name;$('luaCode').value=selected.userData.script||'-- Your script runs when you press Run Script\nprint("Hello from Lua!")\npart:setColor("#ff9f43")';}
$('editScriptBtn').onclick=openScript;$('closeScript').onclick=()=>$('scriptModal').classList.add('hidden');
$('saveScriptBtn').onclick=()=>{if(!selected)return;selected.userData.script=$('luaCode').value;markChanged();toast('Lua script saved to '+selected.name)};
$('runScriptBtn').onclick=async()=>{if(!selected){toast('Select an object first');return}selected.userData.script=$('luaCode').value;$('console').textContent='';await lua.run(selected.userData.script,selected);};
$('stopScriptBtn').onclick=()=>{lua.stop();appendConsole('Scripts stopped.')};
$('clearConsoleBtn').onclick=()=>$('console').textContent='';
function startPlay(){playing=true;savedCamera=engine.getCameraState();engine.detachTransform();engine.orbit.enabled=false;physics.start(engine.objects);$('playBtn').textContent='■ Stop';$('playBtn').classList.add('running');$('hint').textContent='Play mode: WASD to move the test character. Press Stop to edit.';$('hint').style.display='block';$('status').textContent='Play mode';toast('Play mode started')}
function stopPlay(){if(!playing)return;playing=false;physics.stop();lua.stop();engine.orbit.enabled=true;engine.restoreCamera(savedCamera);savedCamera=null;$('playBtn').textContent='▶ Play';$('playBtn').classList.remove('running');$('hint').textContent=selected?'':'Insert a part or select an object to begin.';$('hint').style.display=selected?'none':'block';$('status').textContent='Edit mode';if(selected)engine.select(selected);toast('Back to Edit mode')}
$('playBtn').onclick=()=>playing?stopPlay():startPlay();
window.addEventListener('keydown',e=>{keys[e.key.toLowerCase()]=true;if(playing&&['w','a','s','d',' '].includes(e.key.toLowerCase()))e.preventDefault();if(e.key==='Delete'&&!playing&&selected)$('deleteBtn').click();if(e.key==='Escape'&&playing)stopPlay()});
window.addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);
function animate(now){requestAnimationFrame(animate);const dt=Math.min((now-lastTime)/1000,.04);lastTime=now;if(playing){physics.step(dt,keys);lua.step(dt)}engine.update(dt);$('cameraInfo').textContent=`Camera ${round(engine.camera.position.x)}, ${round(engine.camera.position.y)}, ${round(engine.camera.position.z)}`}
requestAnimationFrame(animate);
engine.addPart('Block',{name:'Part',position:[0,1,0],color:'#4b8df8',scale:[2,2,2]});
engine.addPart('Platform',{name:'Platform',position:[0,-.25,0],color:'#3f8d62',scale:[10,.5,10],anchored:true});
select(null);renderTree();historyButtons();
