STUDIO ENGINE — PHYSICS + LUA PROTOTYPE

Files:
- index.html: editor interface
- style.css: interface styling
- main.js: editor wiring, properties, play mode, script editor
- scene.js: Three.js scene, camera, selection, transform gizmos
- physics.js: Cannon-es physics world, gravity, rigid bodies, collisions, test character
- lua-runtime.js: Fengari Lua interpreter bridge
- project.js: JSON save/load

Run:
This project uses JavaScript modules and imports libraries from jsDelivr CDN. Do not open index.html directly from file://.
Upload all files to the same GitHub repository and enable GitHub Pages, or run a local static web server. Internet access is needed to load the libraries.

Lua example:
print("Hello from Lua!")
part.setColor("#ff9f43")
part.setPosition(0, 3, 0)
print(part.getName())

Available Lua functions:
print(...), warn(...), setColor(hex), setPosition(x,y,z), setName(name), getName(), getPosition(), getObjectCount(), impulse(x,y,z)
Object-bound helpers are exposed through the `part` table, e.g. `part.setColor("#ff9f43")`.
`workspace.getObjectCount()` returns the number of scene objects.

Important limitations:
- This is an educational browser prototype, not Roblox Studio and not Roblox's full Luau API.
- Lua is run in the browser via Fengari, with a limited API. Roblox services, Instances, events, networking, DataStores, and Luau-specific features are not implemented.
- Physics is powered by cannon-es. This is a starter rigid-body setup, not a complete character controller or production physics system.
- The Lua API currently executes synchronously; wait() and Roblox event loops are not implemented.
- External CDN imports require an internet connection.
